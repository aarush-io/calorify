import { initializeApp } from "firebase/app";
import {
  getFirestore,
  enableIndexedDbPersistence,
  collection,
  doc,
  setDoc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  orderBy,
  limit,
  where,
  writeBatch,
  serverTimestamp,
  Timestamp,
} from "firebase/firestore";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  signInAnonymously,
  onAuthStateChanged,
  signOut,
  User,
} from "firebase/auth";
import { APP_CONFIG } from "../../config/app.config";
import { format, parseISO, startOfDay } from "date-fns";

// ── Firebase Init ──────────────────────────────────────────────
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN,
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
  appId: import.meta.env.VITE_FIREBASE_APP_ID,
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const auth = getAuth(app);

// Enable offline persistence
if (APP_CONFIG.cloud.enableOfflinePersistence) {
  enableIndexedDbPersistence(db).catch((err) => {
    if (err.code === "failed-precondition") {
      console.warn("Firestore persistence failed: multiple tabs open");
    } else if (err.code === "unimplemented") {
      console.warn("Firestore persistence not supported in this browser");
    }
  });
}

// ── Types ──────────────────────────────────────────────────────
export interface FoodItem {
  id: string;
  name: string;
  calories: number;
  emoji: string;
  category: string;
  order: number;
  defaultChecked: boolean;
  createdAt?: Timestamp;
}

export interface DailyLog {
  date: string; // YYYY-MM-DD
  checkedFoods: string[]; // food item IDs
  totalCalories: number;
  completed: boolean;
  completionPercent: number;
  weight?: number;
  updatedAt?: Timestamp;
}

export interface UserSettings {
  dailyCalorieGoal: number;
  notifications: boolean;
  reminderMorning: string;
  reminderEvening: string;
  weightUnit: string;
}

// ── Auth ───────────────────────────────────────────────────────
const googleProvider = new GoogleAuthProvider();

export const signInWithGoogle = () => signInWithPopup(auth, googleProvider);
export const signInAsGuest = () => signInAnonymously(auth);
export const signOutUser = () => signOut(auth);
export const onAuthChange = (cb: (user: User | null) => void) => onAuthStateChanged(auth, cb);

// ── Helpers ────────────────────────────────────────────────────
const userRef = (uid: string) => doc(db, "users", uid);
const foodsCol = (uid: string) => collection(db, "users", uid, "foods");
const logsCol = (uid: string) => collection(db, "users", uid, "dailyLogs");
const foodDoc = (uid: string, fid: string) => doc(db, "users", uid, "foods", fid);
const logDoc = (uid: string, date: string) => doc(db, "users", uid, "dailyLogs", date);

// ── User Bootstrap ─────────────────────────────────────────────
export async function bootstrapUser(uid: string, displayName: string | null) {
  const ref = userRef(uid);
  const snap = await getDoc(ref);

  if (!snap.exists()) {
    // First time user — seed default foods from config
    const batch = writeBatch(db);

    batch.set(ref, {
      displayName,
      createdAt: serverTimestamp(),
      settings: {
        dailyCalorieGoal: APP_CONFIG.diet.dailyCalorieGoal,
        notifications: false,
        reminderMorning: APP_CONFIG.reminders.morning,
        reminderEvening: APP_CONFIG.reminders.evening,
        weightUnit: APP_CONFIG.diet.weightUnit,
      },
    });

    APP_CONFIG.defaultFoods.forEach((food, i) => {
      const fRef = doc(foodsCol(uid));
      batch.set(fRef, {
        ...food,
        order: i,
        createdAt: serverTimestamp(),
      });
    });

    await batch.commit();
  }
}

// ── Foods CRUD ─────────────────────────────────────────────────
export async function getFoods(uid: string): Promise<FoodItem[]> {
  const snap = await getDocs(query(foodsCol(uid), orderBy("order", "asc")));
  return snap.docs.map((d) => ({ id: d.id, ...d.data() } as FoodItem));
}

export function subscribeFoods(uid: string, cb: (foods: FoodItem[]) => void) {
  return onSnapshot(query(foodsCol(uid), orderBy("order", "asc")), (snap) => {
    cb(snap.docs.map((d) => ({ id: d.id, ...d.data() } as FoodItem)));
  });
}

export async function addFood(uid: string, food: Omit<FoodItem, "id" | "createdAt">) {
  const ref = doc(foodsCol(uid));
  await setDoc(ref, { ...food, createdAt: serverTimestamp() });
  return ref.id;
}

export async function updateFood(uid: string, fid: string, updates: Partial<FoodItem>) {
  await setDoc(foodDoc(uid, fid), updates, { merge: true });
}

export async function deleteFood(uid: string, fid: string) {
  const { deleteDoc } = await import("firebase/firestore");
  await deleteDoc(foodDoc(uid, fid));
}

export async function reorderFoods(uid: string, foods: FoodItem[]) {
  const batch = writeBatch(db);
  foods.forEach((f, i) => {
    batch.update(foodDoc(uid, f.id), { order: i });
  });
  await batch.commit();
}

// ── Daily Logs ─────────────────────────────────────────────────
export function todayKey(): string {
  return format(new Date(), "yyyy-MM-dd");
}

export async function getLog(uid: string, date: string): Promise<DailyLog | null> {
  const snap = await getDoc(logDoc(uid, date));
  return snap.exists() ? (snap.data() as DailyLog) : null;
}

export function subscribeLog(uid: string, date: string, cb: (log: DailyLog | null) => void) {
  return onSnapshot(logDoc(uid, date), (snap) => {
    cb(snap.exists() ? (snap.data() as DailyLog) : null);
  });
}

export async function saveLog(uid: string, log: Omit<DailyLog, "updatedAt">) {
  await setDoc(logDoc(uid, log.date), { ...log, updatedAt: serverTimestamp() }, { merge: true });
}

export async function getHistory(uid: string, days = 30): Promise<DailyLog[]> {
  const snap = await getDocs(
    query(logsCol(uid), orderBy("date", "desc"), limit(days))
  );
  return snap.docs.map((d) => d.data() as DailyLog);
}

export async function getStreak(uid: string): Promise<number> {
  const logs = await getHistory(uid, 100);
  if (!logs.length) return 0;

  const threshold = APP_CONFIG.streaks.completionThreshold;
  let streak = 0;
  const today = format(new Date(), "yyyy-MM-dd");

  // Sort descending
  const sorted = [...logs].sort((a, b) => b.date.localeCompare(a.date));

  for (let i = 0; i < sorted.length; i++) {
    const log = sorted[i];
    // Skip today if not yet completed
    if (log.date === today && log.completionPercent < threshold) continue;
    if (log.completionPercent >= threshold) {
      streak++;
    } else {
      break;
    }
  }
  return streak;
}

// ── Weight Tracking ────────────────────────────────────────────
export async function logWeight(uid: string, date: string, weight: number) {
  await setDoc(logDoc(uid, date), { weight, updatedAt: serverTimestamp() }, { merge: true });
}

// ── User Settings ──────────────────────────────────────────────
export async function getUserSettings(uid: string): Promise<UserSettings | null> {
  const snap = await getDoc(userRef(uid));
  return snap.exists() ? (snap.data()?.settings as UserSettings) : null;
}

export async function updateUserSettings(uid: string, settings: Partial<UserSettings>) {
  await setDoc(userRef(uid), { settings }, { merge: true });
}
